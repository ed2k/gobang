/*
 * test_renju.cpp
 *
 *  Created on: Mar 4, 2021
 *      Author: Maciej Kozarzewski
 */




