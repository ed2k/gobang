/*
 * caro.cpp
 *
 *  Created on: Mar 4, 2021
 *      Author: maciek
 */

#include <alphagomoku/rules/caro.hpp>
#include <alphagomoku/rules/game_rules.hpp>

namespace ag
{
	GameOutcome getOutcomeCaro(const matrix<Sign> &board)
	{
		return GameOutcome::UNKNOWN; // TODO
	}
	GameOutcome getOutcomeCaro(const matrix<Sign> &board, const Move &last_move)
	{
		return GameOutcome::UNKNOWN; // TODO
	}

	GameOutcome getOutcomeCaro(const std::vector<Sign> &line)
	{
		return GameOutcome::UNKNOWN; // TODO
	}
}

